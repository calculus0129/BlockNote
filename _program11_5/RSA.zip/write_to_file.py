import os
def write_to_file(n, e, d):
  dirname = ['keys', 'pub', 'prv']

  path = [os.getcwd()+"/"+dirname[0]+"/"+dirname[1]+"/", os.getcwd()+"/"+dirname[0]+"/"+dirname[2]+"/"]
  if not os.path.isdir(path[0]): os.makedirs(path[0])
  if not os.path.isdir(path[1]): os.makedirs(path[1])
  
  filenumber = [len(os.listdir(path[0])), len(os.listdir(path[1]))]
  
  with open (path[0]+'pukey'+str(filenumber[0])+'.txt', 'w') as f:
    f.write('{0}\n{1}\n'.format(n,e))
    f.flush()
    f.close()
    
  with open (path[1]+'prkey'+str(filenumber[1])+'.txt', 'w') as f:
    f.write('{0}\n{1}\n'.format(n,d))
    f.flush()
    f.close()
#write_to_file(1, 2, 3)
